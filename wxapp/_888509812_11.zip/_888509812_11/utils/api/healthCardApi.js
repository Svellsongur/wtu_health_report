var e = getApp().globalData.ApiRootUrl;

module.exports = {
    overdue_card: e + "/health/mobile/overdue_card/",
    get_user_info: e + "/health/mobile/get_user_info/",
    active_card: e + "/health/mobile/active_card/",
    get_form_info: e + "/health/mobile/get_form_info/",
    get_thermometry_report: e + "/health/mobile/get_thermometry_report/",
    set_phone_info: e + "/health/mobile/test/",
    get_card_report: e + "/health/mobile/get_card_report/",
    get_location_info: e + "/health/mobile/get_location_info/",
    add_sweep_record: e + "/health/mobile/add_sweep_record/",
    getAvatar: e + "/health/mobile/getAvatar/"
};