var e = getApp().globalData.ApiRootUrl;

module.exports = {
    get_form_info: e + "/health/mobile/get_form_info/",
    active_card: e + "/health/mobile/active_card/",
    scan_record_list: e + "/health/mobile/scan_record_list/",
    get_user_info: e + "/health/mobile/get_user_info/",
    scan_record_filter: e + "/health/mobile/scan_record_filter/",
    scan_record_detail: e + "/health/mobile/scan_record_detail/"
};