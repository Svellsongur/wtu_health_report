var e = getApp().globalData.ApiRootUrl;

module.exports = {
    wx_visitor_login_in: e + "/login/wx_visitor_login_in/",
    overdue_card: e + "/health/mobile/overdue_card/",
    get_user_info: e + "/health/mobile/get_user_info/",
    active_card: e + "/health/mobile/active_card/",
    get_form_info: e + "/health/mobile/get_form_info/"
};