module.exports = [ {
    id: 1,
    name: "全家桶的小家",
    longitude: "114.4399093529968",
    latitude: "30.444208108794115",
    address: "这是D1区"
}, {
    id: 2,
    name: "全家桶的小小家",
    longitude: "114.4426988503723",
    latitude: "30.44720492535086",
    address: "这是D2区"
} ];