Page({
    data: {},
    onLoad: function(n) {
        this.setData({
            urls: n.urls
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onShareAppMessage: function() {}
});